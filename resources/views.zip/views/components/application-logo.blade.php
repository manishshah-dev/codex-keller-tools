<svg viewBox="0 0 50 50" xmlns="http://www.w3.org/2000/svg" {{ $attributes }} fill="currentColor">
    <g>
        <!-- Document/Resume Icon -->
        <path d="M30,5H10C8.9,5,8,5.9,8,7v36c0,1.1,0.9,2,2,2h30c1.1,0,2-0.9,2-2V17L30,5z M30,7.4L39.6,17H30V7.4z M40,43H10V7h18v12h12V43z"/>
        <!-- Magnifying Glass -->
        <path d="M15,23c0-3.9,3.1-7,7-7s7,3.1,7,7s-3.1,7-7,7S15,26.9,15,23z M31.7,33.3l-4.2-4.2c1.5-1.8,2.5-4.1,2.5-6.6c0-5.5-4.5-10-10-10s-10,4.5-10,10s4.5,10,10,10c2.5,0,4.8-1,6.6-2.5l4.2,4.2c0.2,0.2,0.5,0.3,0.7,0.3s0.5-0.1,0.7-0.3C32.1,34,32.1,33.7,31.7,33.3z"/>
        <!-- Checkmark -->
        <path d="M14,30l3,3l6-6"/>
    </g>
    <text x="25" y="48" text-anchor="middle" font-size="6" font-family="Arial, sans-serif" font-weight="bold">RAT</text>
</svg>
